const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const modalBackdrop = $("#modalBackdrop");
const modalContent = $("#modalContent");
const toast = $("#toast");
let toastTimer;
let secretClicks = 0;
let score = 0;

$("#year").textContent = new Date().getFullYear();

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2400);
}

function openModal(content) {
  modalContent.innerHTML = content;
  modalBackdrop.hidden = false;
  document.body.style.overflow = "hidden";
  $("#closeModal").focus();
}
function closeModal() {
  modalBackdrop.hidden = true;
  document.body.style.overflow = "";
}
$("#closeModal").addEventListener("click", closeModal);
modalBackdrop.addEventListener("click", e => { if (e.target === modalBackdrop) closeModal(); });
document.addEventListener("keydown", e => { if (e.key === "Escape") closeModal(); });

$$("[data-scroll]").forEach(button => button.addEventListener("click", () => {
  document.getElementById(button.dataset.scroll).scrollIntoView({ behavior: "smooth" });
}));

$("#surpriseButton").addEventListener("click", () => {
  const surprises = [
    "BREAKING NEWS: Moura is literally the plot. 📰",
    "a reminder: minum air dulu, princess. 🧃",
    "you found 1 invisible sticker! (it's on your screen. trust.) ✨",
    "today's mission: do one tiny thing that makes you happy ♡",
    "secret fact: this website is 100% Moura-coded 🎀"
  ];
  $("#surpriseMessage").textContent = surprises[Math.floor(Math.random() * surprises.length)];
  showToast("✨ surprise delivered!");
});

$("#moodOptions").addEventListener("click", e => {
  const button = e.target.closest("button[data-mood]");
  if (!button) return;
  $$(".mood-options button").forEach(b => b.classList.toggle("selected", b === button));
  $("#moodResult").textContent = button.dataset.mood;
  showToast(`mood updated ${button.dataset.face}`);
});

const fortunes = [
  "something small will make you smile today ♡",
  "you are allowed to start over as many times as you need.",
  "your next idea might be your cutest one yet ✧",
  "drink water. even the main character needs hydration.",
  "plot twist: you don't need to have everything figured out.",
  "your vibe is rare collectible edition 🎀",
  "go make something silly. the world needs more silly.",
  "tiny progress is still progress, bestie."
];
function newFortune() {
  $("#fortuneText").textContent = fortunes[Math.floor(Math.random() * fortunes.length)];
  $(".cookie").style.transform = `rotate(${Math.random() * 30 - 15}deg) scale(1.1)`;
}
$("#fortuneButton").addEventListener("click", newFortune);
$(".cookie").addEventListener("click", newFortune);

const playlists = [
  "main character in her bedroom",
  "sparkly thoughts at 1:37 AM",
  "walking like the sidewalk is a runway",
  "cute but mildly chaotic",
  "daydreaming with the window open",
  "doing absolutely nothing, professionally"
];
$("#playlistButton").addEventListener("click", () => {
  let next = playlists[Math.floor(Math.random() * playlists.length)];
  $("#playlistMood").textContent = `now playing: ${next}`;
});

$("#themeButton").addEventListener("click", () => {
  document.body.classList.toggle("night");
  $("#themeButton").textContent = document.body.classList.contains("night") ? "☾" : "☼";
  showToast(document.body.classList.contains("night") ? "night mode activated ☾" : "sunshine mode activated ☼");
});

const modalTemplates = {
  diary: () => `
    <p class="eyebrow">private-ish pages · entry 001</p>
    <h2>Dear Diary... 📔</h2>
    <p>tulis pikiran random, wishlist, atau cerita hari ini. Catatan ini tersimpan di browser perangkat lo.</p>
    <div class="diary-note">
      <label for="diaryText"><strong>today's tiny thoughts ♡</strong></label>
      <textarea id="diaryText" placeholder="dear diary, hari ini aku..."></textarea>
      <button class="cute-button pink save-note" id="saveDiary">SAVE MY NOTE ♡</button>
      <button class="cute-button cream save-note" id="clearDiary">CLEAR</button>
    </div>
    <p><small>Catatan cuma disimpan secara lokal di browser ini, bukan dikirim ke mana-mana.</small></p>`,
  closet: () => `
    <p class="eyebrow">mix, match & serve</p><h2>Dress-Up Room 👗</h2>
    <p>Pilih vibe outfit Moura hari ini.</p>
    <div class="dress-stage"><div class="dress-avatar" id="dressAvatar">🎀👗🧦</div><div id="outfitName">the pink daydream</div></div>
    <div class="outfit-buttons">
      <button data-outfit="🎀👗🧦" data-name="the pink daydream">🎀 Coquette</button>
      <button data-outfit="🧢👕👟" data-name="weekend chaos">🧢 Y2K</button>
      <button data-outfit="👑🩰✨" data-name="tiny princess energy">👑 Princess</button>
      <button data-outfit="🕶️🖤🥾" data-name="mysterious main character">🕶️ Cool girl</button>
      <button data-outfit="🧸🩷🧦" data-name="professional cozy person">🧸 Comfy</button>
    </div>`,
  arcade: () => `
    <p class="eyebrow">tiny game, big reputation</p><h2>Mini Arcade 🕹️</h2>
    <p>Tekan tombol di bawah buat mengumpulkan poin. Seberapa jauh lo bisa spam klik dalam 10 detik?</p>
    <div class="game-score"><span>YOUR SCORE</span><strong id="gameScore">${score}</strong><button class="cute-button lavender" id="startGame">START 10-SECOND GAME</button><p id="gameStatus">ready? set? clicky clicky!</p></div>`,
  collection: () => `
    <p class="eyebrow">tiny treasures museum</p><h2>My Little Collection 🧸</h2>
    <p>Barang-barang yang bikin hidup terasa 2% lebih imut.</p>
    <div class="collection-list">
      <div class="collection-item"><span>🎀</span>bows & ribbons</div>
      <div class="collection-item"><span>🧸</span>plushie friends</div>
      <div class="collection-item"><span>💿</span>old-school tech</div>
      <div class="collection-item"><span>🧁</span>tiny sweet treats</div>
      <div class="collection-item"><span>📷</span>random memories</div>
      <div class="collection-item"><span>⭐</span>little achievements</div>
    </div>
    <p>Next update: ganti item ini dengan koleksi asli Moura, foto, atau wishlist.</p>`
};

$$("[data-modal]").forEach(button => button.addEventListener("click", () => {
  openModal(modalTemplates[button.dataset.modal]());
  if (button.dataset.modal === "diary") setupDiary();
  if (button.dataset.modal === "closet") setupCloset();
  if (button.dataset.modal === "arcade") setupArcade();
}));

function setupDiary() {
  const field = $("#diaryText");
  try { field.value = localStorage.getItem("mouraDiaryNote") || ""; }
  catch { field.placeholder = "local storage tidak tersedia di browser ini."; }
  $("#saveDiary").addEventListener("click", () => {
    try {
      localStorage.setItem("mouraDiaryNote", field.value);
      showToast("your little note has been saved ♡");
    } catch { showToast("browser ini tidak bisa menyimpan catatan."); }
  });
  $("#clearDiary").addEventListener("click", () => {
    field.value = "";
    try { localStorage.removeItem("mouraDiaryNote"); } catch {}
    showToast("note cleared ✧");
  });
}
function setupCloset() {
  $$(".outfit-buttons button").forEach(button => button.addEventListener("click", () => {
    $("#dressAvatar").textContent = button.dataset.outfit;
    $("#outfitName").textContent = button.dataset.name;
  }));
}
function setupArcade() {
  let active = false;
  let remaining = 10;
  let interval;
  const start = $("#startGame");
  const status = $("#gameStatus");
  const scoreEl = $("#gameScore");
  start.addEventListener("click", () => {
    if (!active) {
      active = true; remaining = 10; score = 0;
      scoreEl.textContent = score;
      start.textContent = "CLICK ME AS FAST AS YOU CAN!";
      status.textContent = "10 seconds... GO GO GO!";
      interval = setInterval(() => {
        remaining--;
        status.textContent = `${remaining} seconds left...`;
        if (remaining <= 0) {
          clearInterval(interval);
          active = false;
          start.textContent = "PLAY AGAIN";
          status.textContent = `final score: ${score} ✧ ${score > 25 ? "certified clicky legend!" : "practice makes chaotic."}`;
        }
      }, 1000);
      return;
    }
    score++;
    scoreEl.textContent = score;
  });
}

$("#secretButton").addEventListener("click", () => {
  secretClicks++;
  if (secretClicks >= 3) {
    secretClicks = 0;
    openModal(`<div style="text-align:center"><div style="font-size:54px">🎀✨🧸</div><p class="eyebrow">you found the secret room</p><h2>certified Moura-coded!</h2><p>achievement unlocked: curious little explorer ♡</p><button class="cute-button pink" id="secretOkay">YAY!</button></div>`);
    $("#secretOkay").addEventListener("click", closeModal);
  } else showToast(`${3 - secretClicks} more click${3 - secretClicks === 1 ? "" : "s"} for a tiny secret...`);
});

// Decorative sparkles; generated locally, no external service.
const sparkleLayer = $("#sparkles");
for (let i = 0; i < 18; i++) {
  const sparkle = document.createElement("span");
  sparkle.textContent = ["✦", "✧", "·", "♡"][i % 4];
  sparkle.style.left = `${(i * 37 + 11) % 98}%`;
  sparkle.style.top = `${(i * 61 + 5) % 96}%`;
  sparkle.style.animationDelay = `${(i % 7) * -.4}s`;
  sparkle.className = "floating-sparkle";
  sparkleLayer.appendChild(sparkle);
}
